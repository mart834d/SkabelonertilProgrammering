﻿using System;
using System.IO;
using System.Net.Sockets;

namespace tcpclient
{
    class Program
    {
        static void Main(string[] args)
        {

            // basisk TCP Client. Hvor den tager udgangspunkt i local host på en port 7000.
            TcpClient clientSocket = new TcpClient("127.0.0.1", 7000);
            Console.WriteLine("Client ready");
            // denne tcp client bruges oftes bare til at chat/sende beskeder.
            Stream ns = clientSocket.GetStream(); //provides a Stream
            StreamReader sr = new StreamReader(ns);
            StreamWriter sw = new StreamWriter(ns);
            sw.AutoFlush = true; // enable automatic flushing
            // vi laver en for lykke for at kunne sende mere end en besked
            for (int i = 0; i < 5; i++)
            {

            

            string message = Console.ReadLine();
            sw.WriteLine(message);
            string serverAnswer = sr.ReadLine();

            Console.WriteLine("Server: " + serverAnswer);

            Console.WriteLine("No more from server. Press Enter");
            Console.ReadLine();
        }

        ns.Close();

            clientSocket.Close();
        }
    }
}
