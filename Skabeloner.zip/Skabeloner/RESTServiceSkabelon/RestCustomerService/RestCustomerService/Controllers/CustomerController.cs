﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using RestCustomerService.Model;

namespace RestCustomerService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private static List<Customer> cList = new List<Customer>();

        static CustomerController()
        {
            Customer c1 = new Customer("Martin", "adsdsadsa", 2019);
            Customer c2 = new Customer("Louise", "asd", 2019);
            Customer c3 = new Customer("Alex", "asd", 2019);
            Customer c4 = new Customer("Dennis", "adsad", 2019);
            Customer c5 = new Customer("Luca", "asdsad", 2019);
            cList.Add(c1);
            cList.Add(c2);
            cList.Add(c3);
            cList.Add(c4);
            cList.Add(c5);
        }

        // GET: api/Customer
        [HttpGet]
        public List<Customer> Get()
        {
            // returnerer vores liste som vi har lavet længere oppe.
            return cList;
        }

        // GET: api/Customer/5
        [HttpGet("{id}", Name = "Get")]
        public Customer Get(int id)
        {
            // Metode til at kalde et objekt ud på en specifik
            var item = cList.SingleOrDefault(c => c.Id == id);
           
            // returnerer den objekt som er tilhænger af den given id.
            return item;
        }

        // POST: api/Customer
        [HttpPost]
        public Customer InsertCustomer([FromBody] Customer customer)
        {
            // Tilføjer en ny customer, hvor vi har lavet en metode, som generer en ID til den.
            customer.Id = Customer.nextId++;
            cList.Add(customer); // kalder add som tilføjer den til listen
            //returnerer customer objektet.
            return customer;
        }

        // PUT: api/Customer/5
        [HttpPut("{id}")]
        public Customer UpdateCustomer(int id, [FromBody] Customer customer)
        {
            //Først finder vi den specifikke customer med den given id, som vi vil ændrer på.
            var item = cList.SingleOrDefault(c => c.Id == id);
            customer.Id = item.Id;

            cList.Remove(item); // kalder remove metoden

            cList.Add(customer); // kalder add metoden.
            // returnerer det nye objekt.
            return customer;
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void DeleteCustomer(int id)
        {
            // først finder vi den specifikke customer.
            var item = cList.SingleOrDefault(c => c.Id == id);
            cList.Remove(item); // Kalder slet på den customer vi finder id'en på.
        }
    }
}
