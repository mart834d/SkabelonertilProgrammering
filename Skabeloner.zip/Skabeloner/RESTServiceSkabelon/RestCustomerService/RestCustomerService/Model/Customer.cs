﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestCustomerService.Model
{
    public class Customer
    {
        // customer klasse, som har nogle full properties. Propfull+tab+tab
        private int _id;
        public static int nextId;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        private string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set { _lastName = value; }
        }
        private int _year;

        public int YearOfRegistration
        {
            get { return _year; }
            set { _year = value; }
        }

        public Customer(string firstName, string lastName, int year)
        {
            // customer constructoren. Sætter grænser for hvordan vi skal lave et nyt customer objekt.
            Id = nextId++; // auto generering af customers id.
            FirstName = firstName;
            LastName = lastName;
            YearOfRegistration = year;
        }        
            
        

        public Customer()
        {
            
        }




    }
}
