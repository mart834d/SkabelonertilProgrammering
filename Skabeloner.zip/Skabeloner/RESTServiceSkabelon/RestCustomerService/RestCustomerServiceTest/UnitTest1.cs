using System.Collections.Generic;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestCustomerService.Controllers;
using RestCustomerService.Model;

namespace RestCustomerServiceTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethodGetId()
        {
            // Testmetode til at f� en en customer
            CustomerController cController = new CustomerController();
            string Expected = "Louise";
            string actual = "";
            Customer c;

            c = cController.Get(1);

            actual = c.FirstName;

            Assert.AreEqual(Expected, actual);
        }

        [TestMethod]
        public void TestMethodGetAll()
        {

            //test metode til at f� alle customers ud.
            //Hvor vi ser om vi f�r det rigtige antal ud, af customer objekter i vores liste.
            CustomerController cController = new CustomerController();

            var testProducts = cController.Get();

            var result = cController.Get() as List<Customer>;

            Assert.AreEqual(testProducts.Count, result.Count);
        }
        [TestMethod]
        public void TestMethodInsert()
        {

            //test metode til at insert et nyt customer objekt til vores liste.
            CustomerController cController = new CustomerController();

            Customer customer = new Customer("Jonas", "Jonas", 1996);

            var test = cController.InsertCustomer(customer);
            var expected = "Jonas";
            var actual = customer.FirstName;

            Assert.AreEqual(expected,actual);
        }
        [TestMethod]
        public void TestMethodDelete()
        {
            //Test metode til at slette et objekt fra vores liste.
            CustomerController cController = new CustomerController();

            cController.Get();
           
            cController.DeleteCustomer(0);
            var actual = cController.Get(0);

            
            Assert.IsNull(actual);

        }
        [TestMethod]
        public void TestMethodUpdate()
        {
            //Test metode til at se om update metoden virker. Hvor vi �ndrer navnet p� en customer objekt.
           CustomerController cc = new CustomerController();
            Customer c = cc.Get(2);

            c.FirstName = c.FirstName + "1";
            Customer x = cc.UpdateCustomer(2, c);
            Assert.AreEqual(c.FirstName, c.FirstName);

        }
    }
    
}
