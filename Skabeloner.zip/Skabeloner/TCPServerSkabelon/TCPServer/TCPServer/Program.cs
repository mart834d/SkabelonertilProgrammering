﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using skat;

namespace TCPServer
{
    class Program
    {
        static void Main(string[] args)
        {
            //Basisk TCP server, som tager udgangspunkt i localhost på en port 7000
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            TcpListener serverSocket = new TcpListener(ip, 7000);
            serverSocket.Start();
            while (true)//denne server sender kun beskeder retur. I form af det input som kommer fra Clienten.
            {
                Console.WriteLine("Server started");

                TcpClient connectionSocket = serverSocket.AcceptTcpClient();

                Console.WriteLine("Server activated");

                Stream ns = connectionSocket.GetStream();


                StreamReader sr = new StreamReader(ns);
                StreamWriter sw = new StreamWriter(ns);
                sw.AutoFlush = true; // enable automatic flushing

                string message = sr.ReadLine().ToLower();
                string answer = "";
                while (message != null && message != "")
                {
                    sw.WriteLine(answer);
                    message = sr.ReadLine();

                }

                ns.Close();
                connectionSocket.Close();


            }

            serverSocket.Stop();

               
        }

        
    }
}
