export interface ICustomer{
    id: number;
    firstname: string;
    lastname: string;
    Year: number;
} 