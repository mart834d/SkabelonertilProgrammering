
import axios, { AxiosError, AxiosResponse, AxiosRequestConfig } from "../../node_modules/axios/index"
import { ICustomer } from "./ICustomer";
// interfaces
let element: HTMLDivElement = <HTMLDivElement>document.getElementById("content");


// kalder på alle customer.
function getAllCustomers(): void{
    axios.get<ICustomer[]>("https://restcustomerservicemartin.azurewebsites.net/api/customer")

        .then(function (Response: AxiosResponse<ICustomer[]>): void{
            console.log(Response);
            let result = ``;
            Response.data.forEach((Customer: ICustomer) => {
                result += ``;
                
            });
        })
        .catch(function (error: AxiosError): void{
        console.log(error)
    })
}

//Tilføjer en customer til restservicen.
function AddCustomer(): void {

    let addFirstnameElement: HTMLInputElement = <HTMLInputElement>document.getElementById("InputFirstName");
    let addLastnameElement: HTMLInputElement = <HTMLInputElement>document.getElementById("InputLastName")
    let addYearElement: HTMLInputElement = <HTMLInputElement>document.getElementById("InputYear")
    
    let myFirstName: string = addFirstnameElement.value;
    let myLastName: string = addLastnameElement.value;
    let myYear: number = +addYearElement.value;

    axios.post<ICustomer>("https://restcustomerservicemartin.azurewebsites.net/api/customer", {
        firstname: myFirstName, lastname: myLastName, year: myYear
    })



        .then(function (Response: AxiosResponse<ICustomer>): void {
            console.log(Response.status)
        })
        .catch(function (error: AxiosError): void {
            console.log(error);
        })
}


//sletter en customer
function DeleteCustomer(): void{
    let id: number = +(<HTMLInputElement>document.getElementById("InputID")).value;
    axios.delete("https://restcustomerservicemartin.azurewebsites.net/api/customer/" + id)
        .then(function (Response: AxiosResponse<ICustomer[]>): void{
    console.log(Response.status)
        })
        .catch(function (error: AxiosError): void{
        console.log(error)
    })
}

// få en customer, udfra et specifikt ID given.
function getOneCustomer(): void{

    let id: number = +(<HTMLInputElement>document.getElementById("Singleid")).value
    axios.get<ICustomer[]>("https://restcustomerservicemartin.azurewebsites.net/api/customer/" + id)

        .then(function (Response: AxiosResponse<ICustomer[]>): void{
            console.log(Response);
            let result = ``;
            Response.data.forEach((Customer: ICustomer) => {
                result += ``;
                
            });
        })
        .catch(function (error: AxiosError): void{
        console.log(error)
    })
}
// Variabler til at få tingene fra HTML.
let GetOneCustomer: HTMLButtonElement = <HTMLButtonElement>document.getElementById("GetOneCustomer")
let DeleteAll: HTMLButtonElement = <HTMLButtonElement>document.getElementById("Delete")
let GetAll: HTMLButtonElement = <HTMLButtonElement>document.getElementById("btn")
let AddCustomerBtn: HTMLButtonElement = <HTMLButtonElement>document.getElementById("AddCustomer")

//click events på knapper
GetOneCustomer.addEventListener("click", getOneCustomer)
DeleteAll.addEventListener("click", DeleteCustomer)
AddCustomerBtn.addEventListener("click",AddCustomer)
GetAll.addEventListener("click", getAllCustomers)

    